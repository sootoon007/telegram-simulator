public class Channel extends Chat{
    Channel(User owner , String id , String name){
        super(owner , id , name);
    }
}
