import java.util.ArrayList;

public class Group extends Chat{
    Group(User owner , String id , String name ){
        super(owner , id , name);
    }

}
